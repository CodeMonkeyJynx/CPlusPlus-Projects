The Town Cryer program, by Dirk Henkemans, is the concept for this story and program. The original version outputs the text "A dragon is coming, take cover!!!" four times and exits.

Using the Town Cryer concept (Town Cryer and dragon characters), I added a story and program modifications for user input to make it a game. Made by Jeffrey W Weger Jr, aka, CodeMonkeyJynx.

This program is dedicated to My Loves, Cassidy and Kristina!!!

Special Thanks to Mark Lee and all those who helped with "C++ Programming for the Absolute Beginner, Second Edition" for helping guide the way to my (hopeful) programming future!

Extra Special Thanks to everyone who downloaded and played the game! I hope it made you chuckle! ;p

And last, but definately not least, to My Beautiful Wife, Laura! Thank you for your support in this new venture. When I doubt myself, you give me the strength and courage to forge on and do things I never thought possible! <3 XOXO <3

This is the completed release verion of my program. Thanks again and have fun! 
-CodeMonkeyJynx-

codemonkeyjynx@gmail.com